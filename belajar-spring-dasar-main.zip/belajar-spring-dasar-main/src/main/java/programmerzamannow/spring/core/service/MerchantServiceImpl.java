package programmerzamannow.spring.core.service;

import org.springframework.stereotype.Component;

@Component
public class MerchantServiceImpl implements MerchantService{
}
