package programmerzamannow.spring.core.repository;

import org.springframework.stereotype.Component;

@Component
public class CategoryRepository {
}
