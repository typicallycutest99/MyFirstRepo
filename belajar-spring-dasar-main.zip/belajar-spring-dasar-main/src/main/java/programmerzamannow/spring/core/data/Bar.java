package programmerzamannow.spring.core.data;

public class Bar {
}
