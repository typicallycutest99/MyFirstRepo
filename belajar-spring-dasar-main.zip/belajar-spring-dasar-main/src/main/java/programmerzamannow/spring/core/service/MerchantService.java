package programmerzamannow.spring.core.service;

public interface MerchantService {
}
