package programmerzamannow.spring.core.repository;

import org.springframework.stereotype.Component;

public class CustomerRepository {
}
