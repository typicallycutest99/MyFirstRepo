package programmerzamannow.spring.core.aware;

public interface IdAware {

  void setId(String id);

  String getId();

}
